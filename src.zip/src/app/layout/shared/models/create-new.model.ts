export interface CreateNewMenuOption {
    id?: number;
    label?: string;
    icon?: string;
}