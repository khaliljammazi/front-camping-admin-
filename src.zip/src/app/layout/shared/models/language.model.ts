
export interface Language {
    id?: number;
    name?: string;
    flag?: string;
}
