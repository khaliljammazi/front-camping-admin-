export interface ProfileOptionItem {
    label?: string;
    icon?: string;
    redirectTo?: string;
}
