export interface Chat {
    id: number;
    avatar: string;
    userName: string;
    message: string;
    userStatus: string;
    group: string;
}