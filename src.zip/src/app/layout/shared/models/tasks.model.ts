export interface Task {
    id: number;
    task: string;
    progress: number;
    variant: string;
    stage: string;
}