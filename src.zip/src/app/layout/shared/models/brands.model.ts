
export interface BrandItem {
    id?: number;
    name?: string;
    logo?: string;
}
