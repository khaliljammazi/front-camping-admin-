export interface MegaMenuItem {
    id?: number;
    menuTitle?: string;
    menuItems?: string[];
}