import { Component, OnInit,ViewEncapsulation  } from '@angular/core';

@Component({
  selector: 'app-client-side',
  templateUrl: './client-side.component.html',
  styleUrls: ['./client-side.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ClientSideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
