import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecommerces',
  templateUrl: './ecommerces.component.html',
  styleUrls: ['./ecommerces.component.scss']
})
export class EcommercesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
