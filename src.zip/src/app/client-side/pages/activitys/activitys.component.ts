import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activitys',
  templateUrl: './activitys.component.html',
  styleUrls: ['./activitys.component.scss']
})
export class ActivitysComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
