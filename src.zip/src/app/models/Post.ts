import { User } from "./user";

export class Post {
  id!: number;
  title!: string;
  image!: string;
  details!: string;
  tags!: string[];
  likes!: number;
  dislikes!: number;
  active!: boolean|number;
  createdAt!: Date;
  user!: User;
}