import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
