import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-left-sidebar',
  templateUrl: './left-sidebar.component.html',
  styleUrls: ['./left-sidebar.component.scss']
})
export class LeftSidebarComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
