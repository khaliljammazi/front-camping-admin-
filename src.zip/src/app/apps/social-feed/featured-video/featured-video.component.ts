import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-featured-video',
  templateUrl: './featured-video.component.html',
  styleUrls: ['./featured-video.component.scss']
})
export class FeaturedVideoComponent implements OnInit {

  constructor () { }

  ngOnInit(): void {
  }

}
